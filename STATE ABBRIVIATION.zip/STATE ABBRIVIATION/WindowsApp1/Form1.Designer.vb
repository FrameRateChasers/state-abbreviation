﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnVA = New System.Windows.Forms.Button()
        Me.btnNC = New System.Windows.Forms.Button()
        Me.btnSC = New System.Windows.Forms.Button()
        Me.btnGA = New System.Windows.Forms.Button()
        Me.btnAL = New System.Windows.Forms.Button()
        Me.btnFL = New System.Windows.Forms.Button()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnEXIT = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnVA
        '
        Me.btnVA.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVA.Location = New System.Drawing.Point(48, 25)
        Me.btnVA.Name = "btnVA"
        Me.btnVA.Size = New System.Drawing.Size(204, 65)
        Me.btnVA.TabIndex = 0
        Me.btnVA.Text = "VIRGINIA"
        Me.btnVA.UseVisualStyleBackColor = True
        '
        'btnNC
        '
        Me.btnNC.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNC.Location = New System.Drawing.Point(298, 25)
        Me.btnNC.Name = "btnNC"
        Me.btnNC.Size = New System.Drawing.Size(204, 65)
        Me.btnNC.TabIndex = 1
        Me.btnNC.Text = "NORTH CAROLINA"
        Me.btnNC.UseVisualStyleBackColor = True
        '
        'btnSC
        '
        Me.btnSC.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSC.Location = New System.Drawing.Point(48, 116)
        Me.btnSC.Name = "btnSC"
        Me.btnSC.Size = New System.Drawing.Size(204, 65)
        Me.btnSC.TabIndex = 2
        Me.btnSC.Text = "SOUHT CAROLINA"
        Me.btnSC.UseVisualStyleBackColor = True
        '
        'btnGA
        '
        Me.btnGA.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGA.Location = New System.Drawing.Point(298, 116)
        Me.btnGA.Name = "btnGA"
        Me.btnGA.Size = New System.Drawing.Size(204, 65)
        Me.btnGA.TabIndex = 3
        Me.btnGA.Text = "GEORGIA"
        Me.btnGA.UseVisualStyleBackColor = True
        '
        'btnAL
        '
        Me.btnAL.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAL.Location = New System.Drawing.Point(48, 211)
        Me.btnAL.Name = "btnAL"
        Me.btnAL.Size = New System.Drawing.Size(204, 65)
        Me.btnAL.TabIndex = 4
        Me.btnAL.Text = "ALABAMA"
        Me.btnAL.UseVisualStyleBackColor = True
        '
        'btnFL
        '
        Me.btnFL.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFL.Location = New System.Drawing.Point(298, 211)
        Me.btnFL.Name = "btnFL"
        Me.btnFL.Size = New System.Drawing.Size(204, 65)
        Me.btnFL.TabIndex = 5
        Me.btnFL.Text = "FLORIDA"
        Me.btnFL.UseVisualStyleBackColor = True
        '
        'lblOutput
        '
        Me.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutput.Location = New System.Drawing.Point(12, 301)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(524, 65)
        Me.lblOutput.TabIndex = 6
        Me.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(27, 389)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(215, 95)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnEXIT
        '
        Me.btnEXIT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEXIT.Location = New System.Drawing.Point(321, 389)
        Me.btnEXIT.Name = "btnEXIT"
        Me.btnEXIT.Size = New System.Drawing.Size(215, 95)
        Me.btnEXIT.TabIndex = 8
        Me.btnEXIT.Text = "EXIT"
        Me.btnEXIT.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(575, 515)
        Me.Controls.Add(Me.btnEXIT)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.btnFL)
        Me.Controls.Add(Me.btnAL)
        Me.Controls.Add(Me.btnGA)
        Me.Controls.Add(Me.btnSC)
        Me.Controls.Add(Me.btnNC)
        Me.Controls.Add(Me.btnVA)
        Me.Name = "Form1"
        Me.Text = "STATE ABBRIVIATIONS"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnVA As Button
    Friend WithEvents btnNC As Button
    Friend WithEvents btnSC As Button
    Friend WithEvents btnGA As Button
    Friend WithEvents btnAL As Button
    Friend WithEvents btnFL As Button
    Friend WithEvents lblOutput As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents btnEXIT As Button
End Class
