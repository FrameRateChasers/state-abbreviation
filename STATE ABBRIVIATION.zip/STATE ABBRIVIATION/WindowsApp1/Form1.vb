﻿Public Class Form1
    'JEFFREY HAGAN
    'VB FOR BUSINESS
    'STATE ABBRIVIATION
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblOutput.Text = ""
    End Sub

    Private Sub btnVA_Click(sender As Object, e As EventArgs) Handles btnVA.Click
        lblOutput.Text = "VA"
    End Sub

    Private Sub btnNC_Click(sender As Object, e As EventArgs) Handles btnNC.Click
        lblOutput.Text = "NC"
    End Sub

    Private Sub btnSC_Click(sender As Object, e As EventArgs) Handles btnSC.Click
        lblOutput.Text = "SC"
    End Sub

    Private Sub btnGA_Click(sender As Object, e As EventArgs) Handles btnGA.Click
        lblOutput.Text = "GA"
    End Sub

    Private Sub btnAL_Click(sender As Object, e As EventArgs) Handles btnAL.Click
        lblOutput.Text = "AL"
    End Sub

    Private Sub btnFL_Click(sender As Object, e As EventArgs) Handles btnFL.Click
        lblOutput.Text = "FL"
    End Sub

    Private Sub btnEXIT_Click(sender As Object, e As EventArgs) Handles btnEXIT.Click
        Me.Close()
    End Sub
End Class
